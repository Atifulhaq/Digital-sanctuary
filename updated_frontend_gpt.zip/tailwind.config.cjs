module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: { colors: { green: { light: '#a8e6cf', DEFAULT: '#4caf50', dark: '#388e3c' }, },
    extend: {
      colors: {
        dsBlue: "#1e6fb3",
        dsGreen: "#2aa876",
        dsNeutral: "#f7fafc",
      },
    },
  },
  plugins: [],
}
