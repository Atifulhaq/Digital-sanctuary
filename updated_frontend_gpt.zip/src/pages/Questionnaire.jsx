import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import ProgressBar from "../components/ProgressBar";
import Question from "../components/Question";

const QUESTIONS = [
  {
    id: "organisation",
    text: "What is the name of your church or charity?",
    type: "text",
  },
  {
    id: "cookie_policy",
    text: "Do you have a cookies policy published on your website?",
    type: "radio",
    options: ["Yes", "No"],
  },
  {
    id: "cookie_banner",
    text: "Does your website show a cookie consent banner?",
    type: "radio",
    options: ["Yes", "No"],
  },
  {
    id: "data_map",
    text: "Do you maintain a personal data inventory?",
    type: "radio",
    options: ["Yes", "No"],
  },
  {
    id: "special_data",
    text: "Do you process any special category data (e.g., health data)?",
    type: "radio",
    options: ["Yes", "No", "Not sure"],
  },
  {
    id: "evidence",
    text: "Upload supporting evidence (optional)",
    type: "file",
  },
];

export default function Questionnaire() {
  const { register, handleSubmit } = useForm();
  const [index, setIndex] = useState(0);
  const navigate = useNavigate();

  const onSubmit = (answers) => {
    const scores = {
      GDPR:
        (answers.cookie_policy === "Yes" ? 40 : 15) +
        (answers.data_map === "Yes" ? 40 : 10),
      PECR: answers.cookie_banner === "Yes" ? 80 : 30,
      DUAA: answers.special_data === "Yes" ? 40 : 80,
    };
    Object.keys(scores).forEach((k) => {
      scores[k] = Math.min(100, Math.max(0, Math.round(scores[k])));
    });
    const overall = Math.round(
      (scores.GDPR + scores.PECR + scores.DUAA) / 3
    );

    const report = {
      id: Date.now(),
      created: new Date().toISOString(),
      answers,
      scores,
      overall,
    };

    localStorage.setItem(`report_${report.id}`, JSON.stringify(report));
    navigate(`/report/${report.id}`);
  };

  const currentQuestion = QUESTIONS[index];

  return (
    <div className="max-w-xl mx-auto">
      <ProgressBar step={index + 1} total={QUESTIONS.length} />

      <form onSubmit={handleSubmit(onSubmit)}>
        <Question q={currentQuestion} register={register} />

        <div className="flex justify-between mt-6">
          <button
            type="button"
            onClick={() => setIndex((prev) => Math.max(0, prev - 1))}
            className="px-4 py-2 bg-gray-200 rounded"
          >
            Back
          </button>

          {index === QUESTIONS.length - 1 ? (
            <button
              type="submit"
              className="px-4 py-2 bg-dsGreen text-white rounded"
            >
              Generate Report
            </button>
          ) : (
            <button
              onClick={(e) => {
                e.preventDefault();
                setIndex((prev) => Math.min(QUESTIONS.length - 1, prev + 1));
              }}
              className="px-4 py-2 bg-dsBlue text-white rounded"
            >
              Next
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
