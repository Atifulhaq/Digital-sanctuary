import React from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Auth() {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();
  const { login } = useAuth();

  const onSubmit = (d) => {
    login({ name: d.fullName || "User", email: d.email });
    navigate("/dashboard");
  };

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow mt-10">
      <h2 className="text-xl font-semibold mb-4">Register / Login</h2>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
        <input
          {...register("fullName")}
          className="border p-2 w-full rounded"
          placeholder="Full Name"
        />

        <input
          {...register("email")}
          required
          className="border p-2 w-full rounded"
          placeholder="Email"
        />

        <button className="w-full bg-dsBlue text-white py-2 rounded">
          Continue
        </button>
      </form>
      <p className="text-xs text-gray-500 mt-2">
        This is a prototype. Authentication will be connected to the backend in a later sprint.
      </p>
    </div>
  );
}
