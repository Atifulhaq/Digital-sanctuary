import React from "react";

export default function Question({ q, register }) {
  return (
    <div className="bg-white p-4 rounded shadow">
      <p className="font-medium">{q.text}</p>

      {q.type === "radio" &&
        q.options.map((opt) => (
          <label key={opt} className="block mt-2">
            <input
              type="radio"
              value={opt}
              {...register(q.id)}
              className="mr-2"
            />
            {opt}
          </label>
        ))}

      {q.type === "text" && (
        <input
          className="border p-2 rounded w-full mt-3"
          {...register(q.id)}
        />
      )}

      {q.type === "file" && (
        <input type="file" className="mt-3" {...register(q.id)} />
      )}
    </div>
  );
}
