import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="bg-white shadow mb-6">
      <div className="container mx-auto flex justify-between items-center p-4">
        <Link to="/" className="font-bold text-dsBlue text-xl">
          Digital Sanctuary
        </Link>

        <div className="flex gap-4 items-center text-sm">
          <Link to="/questionnaire">Questionnaire</Link>
          <Link to="/dashboard">Reports</Link>

          {user ? (
            <>
              <span>{user.name}</span>
              <button
                onClick={logout}
                className="bg-gray-100 px-3 py-1 rounded"
              >
                Logout
              </button>
            </>
          ) : (
            <Link
              className="bg-dsBlue text-white px-4 py-2 rounded"
              to="/auth"
            >
              Login / Sign up
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
